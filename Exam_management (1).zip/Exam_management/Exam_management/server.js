const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(cors());

// In-memory store for OTPs
const otpStore = {}; // Temporary storage for OTPs

// Root route
app.get('/', (req, res) => {
    res.send('Server is running!');
});

// Route to send OTP
app.post('/send-otp', async (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({ success: false, message: "Email is required." });
    }    

    // Generate and store OTP with expiry
    const otp = Math.floor(100000 + Math.random() * 900000);
    otpStore[email] = { otp, expiresAt: Date.now() + 300000 }; // Expires in 5 minutes

    // Configure Nodemailer
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'dabc24680@gmail.com',  // Your Gmail address
            pass: 'hyss ytsa eaym yjql',  // App-specific password
        }
    });

    // Email content
    const mailOptions = {
        from: 'dabc24680@gmail.com',
        to: email, // Use the provided email dynamically
        subject: 'Your OTP Code',
        text: `Hello! Your OTP code is: ${otp}`
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ success: true, message: 'OTP sent successfully.' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ success: false, message: 'Failed to send OTP. Please try again later.' });
    }
});

// Route to verify OTP
app.post('/verify-otp', (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp) {
        return res.status(400).json({ success: false, message: "Email and OTP are required." });
    }

    const storedData = otpStore[email];

    if (!storedData) {
        return res.status(400).json({ success: false, message: "No OTP found for this email." });
    }

    // Check if OTP has expired
    if (Date.now() > storedData.expiresAt) {
        delete otpStore[email];  // Remove expired OTP
        return res.status(400).json({ success: false, message: "OTP has expired." });
    }

    // Validate OTP
    if (storedData.otp != otp) {  // Ensure string vs number comparison
        return res.status(400).json({ success: false, message: "Invalid OTP." });
    }

    // OTP is valid, remove it from the store
    delete otpStore[email];
    res.status(200).json({ success: true, message: "OTP verified successfully!" });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const query = 'SELECT role FROM users WHERE email = ? AND password = ?';
    db.query(query, [email, password], (err, results) => {
        if (err) {
            console.error('Error querying database:', err);
            return res.status(500).json({ success: false, message: 'Server error. Please try again later.' });
        }

        if (results.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid email or password.' });
        }

        const userRole = results[0].role;
        res.status(200).json({ success: true, role: userRole });
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

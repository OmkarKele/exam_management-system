// Send OTP to email
document.getElementById('send-otp').addEventListener('click', async () => {
    const email = document.getElementById('email').value;
  
    if (!email) {
      alert("Please enter your email.");
      return;
    }
  
    // Disable the button to prevent multiple clicks
    const sendOtpButton = document.getElementById('send-otp');
    sendOtpButton.disabled = true;
    sendOtpButton.textContent = "Sending...";
  
    try {
      const response = await fetch('http://localhost:3000/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
  
      // Ensure response is valid JSON
      const result = await response.json().catch(() => {
        throw new Error("Invalid server response");
      });
  
      if (response.ok && result.success) {
        document.getElementById('otp-section').style.display = "block";
        alert("OTP sent to your email.");
      } else {
        alert(result.message || "Failed to send OTP. Please try again.");
      }
    } catch (error) {
      if (error instanceof TypeError && error.message === "Failed to fetch") {
        alert("Unable to connect to the server. Ensure it is running and accessible.");
      } else {
        alert("An unexpected error occurred. Please try again later.");
      }
      console.error("Error sending OTP:", error);
    } finally {
      // Re-enable the button
      sendOtpButton.disabled = false;
      sendOtpButton.textContent = "Send OTP";
    }
  });
  
  // Verify OTP
  document.getElementById('verify-otp').addEventListener('click', async () => {
    const otp = document.getElementById('otp').value;
    const email = document.getElementById('email').value;
  
    if (!otp) {
      alert("Please enter the OTP.");
      return;
    }
  
    const verifyOtpButton = document.getElementById('verify-otp');
    verifyOtpButton.disabled = true;
    verifyOtpButton.textContent = "Verifying...";
  
    try {
      const response = await fetch('http://localhost:3000/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp })
      });

      if (!response.ok) {
        const errorText = await response.text(); // or response.json() if the server sends JSON
        throw new Error(errorText || "Server error");
    }

      // Ensure response is valid JSON
      const result = await response.json().catch(() => {
        throw new Error("Invalid server response");
      });
  
      if (response.ok && result.success) {
        alert("OTP verified successfully! Your account is created.");
        document.getElementById('signup-form').style.display = "none";
        document.getElementById('login-form').style.display = "block";
      } else {
        alert(result.message || "Invalid OTP. Please try again.");
      }
    } catch (error) {
      if (error instanceof TypeError && error.message === "Failed to fetch") {
        alert("Unable to connect to the server. Ensure it is running and accessible.");
      } else {
        alert("An unexpected error occurred. Please try again later.");
      }
      console.error("Error verifying OTP:", error);
    } finally {
      // Re-enable the button
      verifyOtpButton.disabled = false;
      verifyOtpButton.textContent = "Verify OTP";
    }
  });

  document.getElementById('login-btn').addEventListener('click', async () => {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    // Sample login verification (replace with real server check)
    if (email && password) {
        // Example condition
        window.location.href = 'dashboard.html'; // Redirect to the dashboard
    } else {
        alert('Invalid email or password.');  // Handle invalid login
    }
});





  